﻿using Microsoft.VisualStudio.TestPlatform.ObjectModel;
using System;
using System.IO;
using System.Text;

public static class Tournament
{
    /*
    Consigna:
        Cuente los resultados de una pequeña competición de fútbol.

        A partir de un archivo de entrada que contiene qué equipo jugó contra qué equipo y cuál fue el resultado, cree un archivo con una tabla como esta:

        Team                           | MP |  W |  D |  L |  P
        Devastating Donkeys            |  3 |  2 |  1 |  0 |  7
        Allegoric Alaskans             |  3 |  2 |  0 |  1 |  6
        Blithering Badgers             |  3 |  1 |  0 |  2 |  3
        Courageous Californians        |  3 |  0 |  1 |  2 |  1

        ¿Qué significan esas abreviaturas?

        MP: Partidos jugados
        W: Partidos ganados
        D: Partidos Empatados
        L: Partidos perdidos
        P: Puntos

        Una victoria le otorga al equipo 3 puntos. Un empate le otorga 1. Una derrota le otorga 0.

        El resultado se ordena por puntos, en orden descendente. En caso de empate, los equipos se ordenan alfabéticamente.

        Su programa de conteo recibirá una entrada similar a la siguiente:
            Allegoric Alaskans;Blithering Badgers;win
            Devastating Donkeys;Courageous Californians;draw
            Devastating Donkeys;Allegoric Alaskans;win
            Courageous Californians;Blithering Badgers;loss
            Blithering Badgers;Devastating Donkeys;loss
            Allegoric Alaskans;Courageous Californians;win

        El resultado del partido se refiere al primer equipo que aparece en la lista. Así que esta línea:
            Allegoric Alaskans;Blithering Badgers;win
        significa que los Allegoric Alaskans vencieron a los Blithering Badgers.

        Esta linea:
            Courageous Californians;Blithering Badgers;loss
        significa que los Blithering Badgers vencieron a los Courageous Californians.

        Y esta linea:
            Devastating Donkeys;Courageous Californians;draw
        significa que los Devastating Donkeys y los Courageous Californians empataron.

    */

    public static string Tally(string input)
    {
        throw new NotImplementedException("You need to implement this method.");
    }
}